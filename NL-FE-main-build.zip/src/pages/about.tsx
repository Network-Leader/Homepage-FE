import { GlobalContainer } from "../styles/layout/layout";

const About = () => {
  return <GlobalContainer></GlobalContainer>;
};

export default About;
