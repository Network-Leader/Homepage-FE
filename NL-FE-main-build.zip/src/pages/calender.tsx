import { GlobalContainer } from "../styles/layout/layout";

const Calender = () => {
  return <GlobalContainer></GlobalContainer>;
};

export default Calender;
