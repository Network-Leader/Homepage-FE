import { GlobalContainer } from "../styles/layout/layout";

const Board = () => {
  return <GlobalContainer></GlobalContainer>;
};

export default Board;
