const AddModalTag = () => {
  return null;
};

export default AddModalTag;
