import Form from "./Form";

const SignIn = () => {
  return <Form />;
};

export default SignIn;
