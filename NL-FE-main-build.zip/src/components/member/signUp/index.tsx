import Form from "./Form";

const SignUp = () => {
  return <Form />;
};

export default SignUp;
